RED SILVER ANALOG - Galaxy Watch 6

SOURCE PROJECT (not an APK). This project has NOT been compiled or tested on a watch.

Requires a Windows/Mac/Linux computer with Android Studio and Android SDK.
1. Open this folder as an Android Studio project.
2. Let Gradle sync. Check WFF XML and metadata using Android Studio validator; update if flagged.
3. Pair Galaxy Watch 6 using Wireless debugging / Pair new device, or use emulator.
4. Build/install watch APK from Android Studio and select Red Silver Analog on the watch.

Watch Face Format v1 targets Wear OS 4+; Galaxy Watch 6 support depends on current firmware.
The preview icon is the static dial; actual hour/minute/second hands are time-driven by Wear OS.

The separate Android phone-based designer/exporter is not yet implemented.
